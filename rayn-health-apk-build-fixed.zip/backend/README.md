# RayN Health API

Install:
`pip install -r requirements.txt`

Configure:
Copy `.env.example` to `.env` and set `ANTHROPIC_API_KEY`.

Run:
`uvicorn main:app --host 0.0.0.0 --port 8000`

Health:
`GET /health`

The frontend expects:
`POST /api/estimate`

For production Android use, put the API behind HTTPS and reverse-proxy `/api/estimate` to this service. Do not ship the Anthropic API key inside the APK.
