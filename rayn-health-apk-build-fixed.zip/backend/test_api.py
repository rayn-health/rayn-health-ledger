# Smoke test:
# 1. Start the server.
# 2. GET /health -> {"ok":true}
# 3. POST /api/estimate with {"text":"two eggs and toast"}.
