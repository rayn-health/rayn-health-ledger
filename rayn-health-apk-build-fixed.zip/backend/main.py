import base64
import json
import os
import re
from typing import Optional

import anthropic
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

load_dotenv()

app = FastAPI(title="RayN Health Estimate API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

class EstimateRequest(BaseModel):
    text: Optional[str] = None
    imageBase64: Optional[str] = None

def parse_json(text: str):
    text = re.sub(r"```json|```", "", text).strip()
    match = re.search(r"\{.*\}", text, re.S)
    if not match:
        raise ValueError("Model did not return JSON")
    data = json.loads(match.group(0))
    required = ["name","calories","protein_g","carbs_g","fat_g"]
    for key in required:
        if key not in data:
            raise ValueError(f"Missing {key}")
    return {
        "name": str(data["name"])[:120],
        "calories": max(0, round(float(data["calories"]))),
        "protein_g": max(0, round(float(data["protein_g"]), 1)),
        "carbs_g": max(0, round(float(data["carbs_g"]), 1)),
        "fat_g": max(0, round(float(data["fat_g"]), 1)),
    }

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/api/estimate")
def estimate(req: EstimateRequest):
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        raise HTTPException(500, "ANTHROPIC_API_KEY is not configured on the server.")

    if not req.text and not req.imageBase64:
        raise HTTPException(400, "Provide text or imageBase64.")

    client = anthropic.Anthropic(api_key=api_key)
    instruction = (
        'Return ONLY valid JSON: '
        '{"name":string,"calories":number,"protein_g":number,'
        '"carbs_g":number,"fat_g":number}. '
        'Give one realistic estimate for the visible/stated portion. '
        'Do not include markdown or explanations.'
    )

    if req.imageBase64:
        try:
            base64.b64decode(req.imageBase64, validate=True)
        except Exception:
            raise HTTPException(400, "Invalid base64 image.")
        content = [
            {
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": "image/jpeg",
                    "data": req.imageBase64,
                },
            },
            {"type": "text", "text":
                "Identify the food/drink in this photo and estimate nutrition for the visible portion. "
                + instruction},
        ]
    else:
        content = [{"type": "text",
                    "text": f"Estimate nutrition for: {req.text}. {instruction}"}]

    try:
        response = client.messages.create(
            model=os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-6"),
            max_tokens=500,
            messages=[{"role": "user", "content": content}],
        )
        output = "".join(getattr(block, "text", "") for block in response.content)
        return parse_json(output)
    except Exception as e:
        raise HTTPException(502, f"Nutrition estimation failed: {e}")
