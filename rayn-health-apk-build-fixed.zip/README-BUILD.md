# RayN Health — APK build

This repository is designed to build the Android APK on GitHub Actions without Android Studio.

## Build

Open **GitHub → Actions → Build RayN Health APK → Run workflow**.

The workflow:
1. Installs Node.js 20 and Java 17.
2. Installs the Capacitor dependencies.
3. Generates the missing native `android/` project with `npx cap add android`.
4. Syncs the `frontend/` web app.
5. Runs Gradle to build `app-debug.apk`.
6. Uploads the APK as the `RayNHealth-debug-apk` artifact.

The generated `android/` directory is intentionally not stored in the repository; it is created on the GitHub runner.

## Important

The APK build itself does not require an Anthropic API key. AI meal estimation does require the deployed FastAPI backend and its server-side `ANTHROPIC_API_KEY`.

Do not put an Anthropic API key in the frontend or APK.
