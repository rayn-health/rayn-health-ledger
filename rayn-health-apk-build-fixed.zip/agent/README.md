# ChatGPT → GitHub Agent (rayn-health)

This agent lets you type an instruction, have ChatGPT write the code change,
and automatically commit + push it to your `rayn-health` GitHub repo — which
then triggers the existing GitHub Actions workflow to build the APK.

```
You → agent → ChatGPT (writes code) → git commit/push → GitHub Actions → APK
```

## 1. One-time setup

```bash
cd agent
python -m venv venv && source venv/bin/activate     # optional but recommended
pip install -r requirements.txt

cp .env.example .env
# edit .env and fill in:
#   OPENAI_API_KEY  - from platform.openai.com
#   GITHUB_TOKEN    - GitHub → Settings → Developer settings →
#                      Personal access tokens → generate one with "repo" scope
#   GITHUB_REPO     - e.g. "yourname/rayn-health"

git clone https://github.com/yourname/rayn-health.git repo
```

`REPO_PATH` in `.env` should point at that local clone (defaults to `./repo`
relative to wherever you run the agent from).

## 2. Give it an instruction

```bash
python chatgpt_github_agent.py "add a dark mode toggle to the settings area" \
  --files frontend/index.html \
  --trigger-build
```

- `--files` — which existing files ChatGPT should see as context (it can
  still create new files if needed).
- `--trigger-build` — after pushing, automatically kicks off the
  "Build RayN Health APK" GitHub Actions workflow via `workflow_dispatch`.
- Omit the instruction and add `--interactive` to be prompted instead.

The agent will show you the proposed commit message and the list of files
about to change, and asks for confirmation before writing/committing/pushing
anything.

## 3. Get the APK

- GitHub → your repo → **Actions** → **Build RayN Health APK** → open the
  latest run → download the `RayNHealth-debug-apk` artifact.
- This happens automatically on every push to `main`, or immediately if you
  passed `--trigger-build`.

## Notes / limits

- This is a single-shot agent: one instruction in, one commit out. It does
  not maintain conversation history between runs.
- It sends full file contents to the OpenAI API and gets full file contents
  back (no diffing), which keeps things reliable for a small project like
  this but isn't ideal for very large files.
- Treat `GITHUB_TOKEN` and `OPENAI_API_KEY` like passwords — `.env` is
  already covered by `.gitignore`, so don't commit it.
- Review the diff (`git log -p` or GitHub's compare view) before trusting
  AI-generated changes in a health-related app, especially anything touching
  the backend's estimation logic.
