#!/usr/bin/env python3
"""
chatgpt_github_agent.py

A small local "agent" that bridges ChatGPT and your rayn-health GitHub repo:

  1. You give it a plain-English instruction
     (e.g. "add a dark mode toggle to the settings screen").
  2. It sends your instruction + the current content of relevant files to
     the OpenAI ChatGPT API, and asks for the full new content of any files
     that need to change (as strict JSON).
  3. It writes those files into a local clone of your repo, commits, and
     pushes to GitHub.
  4. Optionally, it triggers the "Build RayN Health APK" GitHub Actions
     workflow (workflow_dispatch) so a new APK gets built automatically.

Requirements:
    pip install openai PyGithub

Environment variables (put these in a .env file or your shell):
    OPENAI_API_KEY   - your OpenAI API key
    GITHUB_TOKEN     - a GitHub personal access token with `repo` scope
    GITHUB_REPO      - "your-username/rayn-health"
    REPO_PATH        - path to a local clone of that repo (default: ./repo)
    OPENAI_MODEL     - optional, defaults to "gpt-4.1"

Usage:
    python agent/chatgpt_github_agent.py "add a dark mode toggle" \
        --files frontend/index.html \
        --branch main \
        --trigger-build

    # or interactively
    python agent/chatgpt_github_agent.py --interactive
"""

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

try:
    from openai import OpenAI
except ImportError:
    sys.exit("Missing dependency. Run: pip install openai PyGithub")

try:
    from github import Github
except ImportError:
    sys.exit("Missing dependency. Run: pip install openai PyGithub")


SYSTEM_PROMPT = """You are a senior Android/Capacitor engineer working on the \
"rayn-health" app (a Capacitor-wrapped web app with a FastAPI backend, built \
into an APK via GitHub Actions).

You will be given:
- A plain-English instruction describing a change to make.
- The current contents of one or more files.

Respond with ONLY a JSON object (no markdown fences, no commentary) of the form:

{
  "commit_message": "short imperative summary of the change",
  "files": {
    "relative/path/to/file.ext": "FULL new content of that file",
    "relative/path/to/other.ext": "FULL new content of that file"
  }
}

Rules:
- Include the FULL new content for every file you touch, not a diff/patch.
- Only include files that actually changed.
- You may create new files if the instruction requires it (e.g. a new
  frontend component), using paths consistent with the existing project
  layout (frontend/, backend/, .github/workflows/, etc.).
- Never modify .github/workflows/build-apk.yml unless the instruction is
  specifically about the build process.
- Keep changes minimal and focused on the instruction.
"""


def load_env_file(path=".env"):
    """Very small .env loader so users don't need python-dotenv."""
    p = Path(path)
    if not p.exists():
        return
    for line in p.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def run(cmd, cwd):
    print(f"$ {' '.join(cmd)}")
    result = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if result.returncode != 0:
        print(result.stdout)
        print(result.stderr)
        raise RuntimeError(f"Command failed: {' '.join(cmd)}")
    return result.stdout.strip()


def read_files(repo_path: Path, relative_paths):
    contents = {}
    for rel in relative_paths:
        fp = repo_path / rel
        if fp.exists():
            contents[rel] = fp.read_text(encoding="utf-8", errors="replace")
        else:
            contents[rel] = "(file does not exist yet)"
    return contents


def ask_chatgpt(instruction: str, file_contents: dict, model: str) -> dict:
    client = OpenAI()
    user_payload = {
        "instruction": instruction,
        "current_files": file_contents,
    }
    resp = client.chat.completions.create(
        model=model,
        temperature=0,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": json.dumps(user_payload, indent=2)},
        ],
    )
    raw = resp.choices[0].message.content.strip()
    # Be tolerant of accidental markdown fences.
    if raw.startswith("```"):
        raw = raw.strip("`")
        if raw.lower().startswith("json"):
            raw = raw[4:]
    return json.loads(raw)


def apply_and_push(repo_path: Path, plan: dict, branch: str):
    for rel_path, content in plan["files"].items():
        fp = repo_path / rel_path
        fp.parent.mkdir(parents=True, exist_ok=True)
        fp.write_text(content, encoding="utf-8")
        print(f"wrote {rel_path}")

    run(["git", "add", "."], cwd=repo_path)
    status = run(["git", "status", "--porcelain"], cwd=repo_path)
    if not status:
        print("No changes to commit.")
        return False

    commit_message = plan.get("commit_message", "Automated change via ChatGPT agent")
    run(["git", "commit", "-m", commit_message], cwd=repo_path)
    run(["git", "push", "origin", branch], cwd=repo_path)
    return True


def trigger_build_workflow(github_token: str, repo_name: str, branch: str):
    gh = Github(github_token)
    repo = gh.get_repo(repo_name)
    workflow = repo.get_workflow("build-apk.yml")
    ok = workflow.create_dispatch(branch)
    print("Workflow dispatch triggered." if ok else "Failed to trigger workflow.")


def main():
    load_env_file()

    parser = argparse.ArgumentParser(description="ChatGPT -> GitHub agent for rayn-health")
    parser.add_argument("instruction", nargs="?", help="Plain-English instruction")
    parser.add_argument("--files", nargs="*", default=[], help="Relative file paths to give ChatGPT as context")
    parser.add_argument("--branch", default="main", help="Git branch to commit/push to")
    parser.add_argument("--trigger-build", action="store_true", help="Trigger the APK build workflow after pushing")
    parser.add_argument("--interactive", action="store_true", help="Prompt for instruction/files interactively")
    args = parser.parse_args()

    repo_path = Path(os.environ.get("REPO_PATH", "./repo")).resolve()
    github_repo = os.environ.get("GITHUB_REPO")
    github_token = os.environ.get("GITHUB_TOKEN")
    model = os.environ.get("OPENAI_MODEL", "gpt-4.1")

    if not os.environ.get("OPENAI_API_KEY"):
        sys.exit("Set OPENAI_API_KEY (env var or .env file).")
    if not github_repo or not github_token:
        sys.exit("Set GITHUB_REPO and GITHUB_TOKEN (env vars or .env file).")
    if not repo_path.exists():
        sys.exit(
            f"REPO_PATH '{repo_path}' does not exist. Clone your repo there first:\n"
            f"  git clone https://github.com/{github_repo}.git {repo_path}"
        )

    instruction = args.instruction
    files = args.files
    if args.interactive or not instruction:
        instruction = input("Instruction for ChatGPT: ").strip()
        files_raw = input("Files to include as context (space-separated, optional): ").strip()
        files = files_raw.split() if files_raw else files

    file_contents = read_files(repo_path, files)

    print("Asking ChatGPT for changes...")
    plan = ask_chatgpt(instruction, file_contents, model)

    if not plan.get("files"):
        print("ChatGPT proposed no file changes.")
        return

    print(f"Proposed commit: {plan.get('commit_message')}")
    for f in plan["files"]:
        print(f"  - {f}")
    confirm = input("Apply, commit, and push these changes? [y/N] ").strip().lower()
    if confirm != "y":
        print("Aborted.")
        return

    pushed = apply_and_push(repo_path, plan, args.branch)

    if pushed and args.trigger_build:
        trigger_build_workflow(github_token, github_repo, args.branch)


if __name__ == "__main__":
    main()
